# 📘 LTF Glossary (stub)
- **VS** — Verbalized Sampling (Speak to Think)
- **VSyn** — Variable Synchronicity (Think in Time)
- **VcS** — Vector Co-Synthesis (Keep Meaning in Motion)
