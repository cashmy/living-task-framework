# Complete Test

## Bad heading jump (MD001)

No blank line before heading (MD022)

## Another Heading

No blank line after heading (MD022)

  Hard tab here (MD010)
Trailing spaces here

- Asterisk list (MD004)
- Plus list (MD004)
- Too many spaces (MD030)

Three blank lines above (MD012)

```text
No language (MD040)
No blank before/after (MD031)
```

Next line immediately.

All issues combined!
